from macro_engine import MacroShockEngine
import traceback

try:
    print("������ 매크로 엔진 원본 스캔 시작...")
    engine = MacroShockEngine("66f8e6a39938571b83bcdf4bae9b9418")
    df = engine.aggregate_macro_metrics()
    print("--- ������ 컬럼(이름표) 목록 ---")
    print(df.columns.tolist() if df is not None else "데이터 없음(None)")
    print("--- ������ 최근 데이터 ---")
    print(df.tail(2) if df is not None else "데이터 없음(None)")
except Exception as e:
    print("--- ������ 내부 에러 발생 ---")
    traceback.print_exc()
