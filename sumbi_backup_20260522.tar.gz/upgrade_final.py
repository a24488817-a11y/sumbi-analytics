import os, re
filepath = os.path.expanduser("~/main.py")
with open(filepath, "r", encoding="utf-8") as f:
    code = f.read()

# 1. 꼬여있던 이전 UI 잔재물 완벽 청소
code = re.sub(r'# --- QUANTUM UI INJECTION ---.*?# ----------------------------\n', '', code, flags=re.DOTALL)

# 2. 퀀트 터미널 UI + AI 색상 감지 엔진
quantum_ui = """
# --- QUANTUM UI INJECTION ---
def apply_quantum_ui():
    import streamlit as st
    import streamlit.components.v1 as components
    
    st.markdown('''
    <style>
    /* 딥 다크 배경 및 텍스트 (압도적인 무게감) */
    .stApp { background-color: #070B14; color: #F8FAFC; font-family: 'Helvetica Neue', sans-serif; }
    
    /* 메인 타이틀 (고대비 네온 골드 그라데이션) */
    .q-title {
        text-align: center;
        font-size: 3.5rem;
        font-weight: 900;
        background: linear-gradient(135deg, #FFDF73 0%, #D4AF37 50%, #996515 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 5px;
        text-shadow: 0px 4px 20px rgba(212,175,55,0.4);
        letter-spacing: 2px;
    }
    
    /* 서브 타이틀 */
    .q-sub {
        text-align: center;
        color: #94A3B8;
        font-size: 1.1rem;
        letter-spacing: 5px;
        margin-bottom: 30px;
    }
    
    /* 데이터 카드 (테두리 및 입체감) */
    div[data-testid="metric-container"] {
        background-color: #0F172A;
        border: 1px solid #1E293B;
        border-left: 4px solid #D4AF37;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        transition: all 0.3s;
    }
    div[data-testid="metric-container"]:hover {
        border-color: #D4AF37;
        box-shadow: 0 4px 20px rgba(212,175,55,0.2);
        transform: translateY(-2px);
    }
    
    /* 실행 버튼 (월스트리트 블루) */
    .stButton>button {
        width: 100%;
        background: linear-gradient(135deg, #1E3A8A, #2563EB);
        color: white;
        font-weight: 800;
        border: none;
        border-radius: 6px;
        height: 60px;
        font-size: 1.3rem;
        letter-spacing: 2px;
        box-shadow: 0 4px 15px rgba(37,99,235,0.4);
    }
    .stButton>button:hover {
        background: linear-gradient(135deg, #1E3A8A, #1D4ED8);
        border: 1px solid #D4AF37;
    }
    </style>
    
    <div class="q-title">SUMBI QUANTUM</div>
    <div class="q-sub">INSTITUTIONAL GRADE TERMINAL | 42대 주식 필살기</div>
    <hr style="border-color:#1E293B; margin-top:10px;">
    ''', unsafe_allow_html=True)

    # 3. 투명 AI 센서: 한국식 상승(빨강)/하락(파랑) 실시간 자동 색상 스크립트
    components.html('''
    <script>
    function applyColors() {
        // Streamlit 화면 내의 모든 숫자 데이터를 실시간으로 스캔
        const elements = window.parent.document.querySelectorAll('[data-testid="stMetricValue"]');
        elements.forEach(el => {
            const text = el.innerText.replace(/,/g, '').replace(/%/g, '');
            const num = parseFloat(text);
            if (!isNaN(num)) {
                if (num > 0) { 
                    el.style.color = '#EF4444'; // 세력 매수/상승: 강렬한 빨강
                } else if (num < 0) { 
                    el.style.color = '#3B82F6'; // 세력 매도/하락: 차가운 파랑
                }
            }
        });
    }
    // 검색 버튼을 누를 때마다 0.5초 단위로 즉각 색상 반영
    setInterval(applyColors, 500); 
    </script>
    ''', height=0)

apply_quantum_ui()
# ----------------------------
"""

# 가독성 떨어지는 기존 밋밋한 제목 가리기
lines = code.split('\n')
for i, line in enumerate(lines):
    if line.strip().startswith('st.title') or line.strip().startswith('st.header'):
        if '# ' not in line:
            lines[i] = '# ' + line
code = '\n'.join(lines)

# 엔진의 심장부(get_macro) 바로 위에 새 UI 주입
if "apply_quantum_ui()" not in code:
    insert_idx = code.find('def get_macro()')
    if insert_idx != -1:
        code = code[:insert_idx] + quantum_ui + "\n" + code[insert_idx:]
    else:
        code = quantum_ui + "\n" + code

with open(filepath, "w", encoding="utf-8") as f:
    f.write(code)

print("--- ������ SUMBI QUANTUM TERMINAL UPGRADE COMPLETE ---")
